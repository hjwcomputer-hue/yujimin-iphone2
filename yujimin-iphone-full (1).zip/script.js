const qs = s => document.querySelector(s);
const qsa = s => [...document.querySelectorAll(s)];

const screens = {
  lock: qs("#lockScreen"),
  home: qs("#homeScreen"),
  app: qs("#appScreen"),
};
const overlays = {
  cc: qs("#controlCenter"),
  nc: qs("#notificationCenter"),
};
const appView = qs("#appView");
let currentScreen = "lock";
let currentChat = null;

function hideOverlays(){
  Object.values(overlays).forEach(x=>x.classList.remove("active"));
}
function showScreen(name){
  hideOverlays();
  Object.values(screens).forEach(s=>s.classList.remove("active"));
  screens[name].classList.add("active");
  currentScreen = name;
}
function openOverlay(name){
  Object.entries(overlays).forEach(([k,v])=>v.classList.toggle("active", k===name));
}
function nowTime(){
  return new Intl.DateTimeFormat("ko-KR",{hour:"numeric",minute:"2-digit",hour12:false}).format(new Date());
}
function updateClock(){
  const now = new Date();
  const t = nowTime();
  ["#statusTime","#lockTime","#homeClock","#ncTime"].forEach(sel=>{ const el=qs(sel); if(el) el.textContent=t; });
  const d = new Intl.DateTimeFormat("ko-KR",{month:"long",day:"numeric",weekday:"long"}).format(now);
  qs("#lockDate").textContent = d;
  qs("#ncDate").textContent = d;
}
updateClock(); setInterval(updateClock,10000);

qs("#lockScreen").addEventListener("click",(e)=>{
  if(e.target.id==="cameraQuick"){openApp("camera");return;}
  showScreen("home");
});
qs("#homeIndicator").addEventListener("click",()=>showScreen("home"));

qsa("[data-app]").forEach(btn=>btn.addEventListener("click",()=>openApp(btn.dataset.app)));

function header(title, back="홈"){
  return `<div class="app-header"><button onclick="goBack()">&lsaquo; ${back}</button><strong>${title}</strong><span></span></div>`;
}
window.goBack = function(){
  if(currentChat){
    currentChat = null;
    openApp("kakao");
  }else showScreen("home");
};

const apps = {
  kakao(){
    return header("카카오톡") + `<div class="app-body list">
      <div class="row" onclick="openChat('winter')"><div class="avatar">M</div><div class="row-main"><div class="row-title">민정</div><div class="row-sub">끝났어?</div></div><span class="badge">2</span></div>
      <div class="row" onclick="openChat('manager')"><div class="avatar">MGR</div><div class="row-main"><div class="row-title">매니저</div><div class="row-sub">내일 일정 확인 부탁드립니다.</div></div></div>
      <div class="row" onclick="openChat('group')"><div class="avatar">A</div><div class="row-main"><div class="row-title">aespa 단톡</div><div class="row-sub">사진 보냈어 ㅋㅋ</div></div><span class="badge">7</span></div>
      <div class="row"><div class="avatar">S</div><div class="row-main"><div class="row-title">스타일리스트</div><div class="row-sub">피팅 사진 전달드려요!</div></div></div>
    </div>`;
  },
  messages(){
    return header("메시지") + `<div class="app-body list">
      <div class="row"><div class="avatar">♡</div><div class="row-main"><div class="row-title">엄마</div><div class="row-sub">밥 꼭 챙겨 먹어</div></div></div>
      <div class="row"><div class="avatar">S</div><div class="row-main"><div class="row-title">스타일리스트</div><div class="row-sub">피팅 사진 보내드릴게요!</div></div></div>
      <div class="row"><div class="avatar">N</div><div class="row-main"><div class="row-title">닝닝</div><div class="row-sub">언니 어디야</div></div></div>
    </div>`;
  },
  phone(){
    return header("전화") + `<div class="app-body">
      <div class="dial">
        <div class="dial-number" id="dialNumber"></div>
        <div class="keypad">
          ${["1","2","3","4","5","6","7","8","9","*","0","#"].map(n=>`<button class="key" onclick="dial('${n}')">${n}</button>`).join("")}
          <span></span><button class="key callbtn" onclick="fakeCall()">☎</button><button class="key" onclick="backspaceDial()">⌫</button>
        </div>
      </div>
      <div class="phone-tabs"><span>즐겨찾기</span><span>최근 통화</span><span>연락처</span><b>키패드</b><span>음성 사서함</span></div>
    </div>`;
  },
  photos(){
    return header("사진") + `<div class="app-body"><div class="photo-grid">${
      Array.from({length:36},(_,i)=>`<div class="photo">FAN PHOTO ${i+1}</div>`).join("")
    }</div></div>`;
  },
  camera(){
    return header("카메라") + `<div class="app-body camera-view">
      <div class="camera-preview"><span>팬메이드 카메라 미리보기</span></div>
      <div class="camera-controls"><div class="thumb"></div><button class="shutter" onclick="flashIsland('사진 저장됨')"></button><span>↻</span></div>
    </div>`;
  },
  safari(){
    return header("Safari") + `<div class="app-body">
      <div class="safari-top"><div class="address">fanmade.local</div></div>
      <div class="browser-page"><h1>YUJIMIN</h1><p>Fan-made iPhone Home</p>
        <div class="browser-card"><b>즐겨찾기</b><p>팬페이지 · 음악 · 사진 · 일정</p></div>
        <div class="browser-card"><b>개인정보 안내</b><p>이 사이트의 내용은 전부 창작된 팬메이드 예시입니다.</p></div>
      </div>
    </div>`;
  },
  notes(){
    return header("메모") + `<div class="app-body">
      <div class="note"><b>오늘 할 일</b><br><br>• 연습<br>• 스케줄 확인<br>• 사진 정리<br>• 물 많이 마시기<br><br>✿ fan-made note</div>
      <div class="note"><b>사고 싶은 것</b><br><br>• 향초<br>• 새 케이스<br>• 작은 카메라</div>
    </div>`;
  },
  music(){
    return header("음악") + `<div class="app-body music-page">
      <div class="album">YJ</div>
      <small>재생 중</small><h2>My Playlist</h2><p>Fan-made track</p>
      <div class="progress"><span></span></div>
      <div class="player-buttons">◀︎ ▶︎ ▶</div>
    </div>`;
  },
  calendar(){
    return header("캘린더") + `<div class="app-body calendar-page">
      <div class="calendar-title">2026년 10월</div>
      <div class="days">${["일","월","화","수","목","금","토"].map(x=>`<b class="day">${x}</b>`).join("")}
      ${Array.from({length:31},(_,i)=>`<div class="day ${i+1===19?'today':''}">${i+1}</div>`).join("")}</div>
      <div class="note"><b>오늘</b><br>연습 · 촬영 준비 · 휴식</div>
    </div>`;
  },
  clock(){
    return header("시계") + `<div class="app-body clock-page"><div><div id="liveClock" class="big-clock">${nowTime()}</div><p>서울</p></div></div>`;
  },
  weather(){
    return header("날씨") + `<div class="app-body weather-page"><div>서울</div><div class="weather-temp">19°</div><h2>맑음</h2><p>최고 22° · 최저 13°</p><div class="browser-card" style="color:#111;text-align:left"><b>팬메이드 날씨 화면</b><p>실시간 날씨 데이터는 연결하지 않은 데모입니다.</p></div></div>`;
  },
  settings(){
    return header("설정") + `<div class="app-body">
      <div class="settings-group"><div class="setting"><b>YUJIMIN</b><div class="row-sub">Fan-made Apple Account</div></div></div>
      <div class="settings-group">
        <div class="setting">에어플레인 모드 <span class="toggle"></span></div>
        <div class="setting">Wi‑Fi <span style="float:right;color:#777">Studio WiFi ›</span></div>
        <div class="setting">Bluetooth <span style="float:right;color:#777">켬 ›</span></div>
      </div>
      <div class="settings-group">
        <div class="setting">알림 <span style="float:right">›</span></div>
        <div class="setting">사운드 및 햅틱 <span style="float:right">›</span></div>
        <div class="setting">집중 모드 <span style="float:right">›</span></div>
        <div class="setting">배경화면 <span style="float:right">›</span></div>
        <div class="setting">디스플레이 및 밝기 <span style="float:right">›</span></div>
      </div>
    </div>`;
  }
};

function openApp(name){
  currentChat = null;
  appView.innerHTML = apps[name] ? apps[name]() : header("앱")+"<div class='app-body'></div>";
  showScreen("app");
  if(name==="clock"){
    setInterval(()=>{ const el=qs("#liveClock"); if(el) el.textContent=nowTime(); },1000);
  }
}

window.openChat = function(type){
  currentChat = type;
  const chatMap = {
    winter:{
      title:"민정",
      bubbles:[
        ["them","끝났어?"],["me","응 방금!"],["them","그럼 내려와"],["me","왜"],["them","그냥. 빨리"],["me","ㅋㅋ 알겠어"]
      ]
    },
    manager:{
      title:"매니저",
      bubbles:[["them","내일 첫 일정은 오전 리허설입니다."],["me","확인했습니다!"],["them","차량 시간도 다시 보내드릴게요."]]
    },
    group:{
      title:"aespa 단톡",
      bubbles:[["them","사진 보냈어 ㅋㅋ"],["me","아 이건 아니지"],["them","ㅋㅋㅋㅋㅋㅋ"],["me","삭제해줘 제발"]]
    }
  };
  const c=chatMap[type];
  appView.innerHTML = header(c.title,"카카오톡")+`<div class="app-body" style="position:relative">
    <div class="chat"><div class="chat-time">오늘</div>
      ${c.bubbles.map(([side,msg])=>`<div class="bubble ${side}">${msg}</div>`).join("")}
    </div>
    <div class="chat-input"><input id="chatText" placeholder="메시지"><button onclick="sendChat()">전송</button></div>
  </div>`;
  showScreen("app");
}
window.sendChat=function(){
  const input=qs("#chatText"); if(!input || !input.value.trim()) return;
  const chat=qs(".chat"); const div=document.createElement("div"); div.className="bubble me"; div.textContent=input.value.trim(); chat.appendChild(div); input.value=""; chat.scrollTop=chat.scrollHeight;
}
window.dial=function(n){ const el=qs("#dialNumber"); if(el) el.textContent=(el.textContent+n).slice(0,16); }
window.backspaceDial=function(){ const el=qs("#dialNumber"); if(el) el.textContent=el.textContent.slice(0,-1); }
window.fakeCall=function(){ const el=qs("#dialNumber"); flashIsland(el && el.textContent ? "통화 연결 중…" : "번호를 입력하세요"); }
window.flashIsland=function(text){
  const el=qs("#islandText"); el.textContent=text;
  setTimeout(()=>el.textContent="YUJIMIN",1600);
}

/* top gestures */
let startY=0,startX=0;
qs(".phone").addEventListener("pointerdown",e=>{startY=e.clientY;startX=e.clientX;});
qs(".phone").addEventListener("pointerup",e=>{
  const dy=e.clientY-startY, dx=e.clientX-startX;
  if(startY<90 && dy>70){
    if(startX > qs(".phone").getBoundingClientRect().width/2 + qs(".phone").getBoundingClientRect().left) openOverlay("cc");
    else openOverlay("nc");
  }
  if((overlays.cc.classList.contains("active")||overlays.nc.classList.contains("active")) && dy < -70) hideOverlays();
});

qs("#statusbar").addEventListener("dblclick",(e)=>{
  const rect=qs(".phone").getBoundingClientRect();
  openOverlay(e.clientX>rect.left+rect.width/2?"cc":"nc");
});
qsa(".overlay").forEach(o=>o.addEventListener("dblclick",hideOverlays));

qs("#brightness").addEventListener("input",e=>{
  qs(".phone").style.filter=`brightness(${e.target.value/100})`;
});
