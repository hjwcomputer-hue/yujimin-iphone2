# YUJIMIN iPhone — Fan-made

가상 아이폰 UI를 웹으로 만든 팬메이드 프로젝트입니다.

## 포함 기능
- 잠금화면
- 홈화면
- 카카오톡 데모 채팅
- 메시지
- 전화 키패드
- 사진
- 카메라
- Safari
- 메모
- 음악
- 캘린더
- 시계
- 날씨 데모
- 설정
- 제어센터
- 알림센터
- 홈 인디케이터

> 실제 인물의 휴대폰, 연락처, 메시지, 사진을 재현한 것이 아닙니다.
> 화면 안의 내용은 팬메이드 예시입니다.

## 가장 쉬운 실행법
압축을 풀고 `index.html`을 더블클릭하세요.

## GitHub Pages
1. GitHub에서 새 repository 생성
2. 이 폴더의 파일 4개 업로드
3. Settings → Pages
4. Build and deployment → Deploy from a branch
5. Branch `main`, Folder `/(root)` 선택
6. Save
7. 잠시 뒤 표시되는 사이트 주소 열기
